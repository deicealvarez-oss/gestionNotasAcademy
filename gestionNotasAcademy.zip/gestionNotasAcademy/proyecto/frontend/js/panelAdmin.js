const API_URL = 'http://localhost:3000';
let usuarioEnEdicion = null;

function redirectToLogin() {
    alert('Acceso no autorizado. Por favor inicie sesión como administrador.');
    window.location.href = '../index.html';
}

async function cargarUsuarios() {
    try {
        const response = await fetch(`${API_URL}/api/usuarios`);
        if (!response.ok) {
            throw new Error('No se pudo obtener la lista de usuarios');
        }
        const usuarios = await response.json();
        const listaUsuarios = document.getElementById('listaUsuarios');

        if (!listaUsuarios) return;

        listaUsuarios.innerHTML = usuarios.map(usuario => `
            <tr>
                <td>${usuario.id}</td>
                <td>${usuario.nombre}</td>
                <td>${usuario.correo}</td>
                <td>${usuario.direccion || ''}</td>
                <td>${usuario.telefono || ''}</td>
                <td>${usuario.rol}</td>
                <td class="text-center">
                    <button type="button" class="btn btn-sm btn-danger me-1" onclick="eliminarUsuario('${usuario.id}')">Eliminar</button>
                    <button type="button" class="btn btn-sm btn-secondary" onclick="editarUsuario('${usuario.id}', '${usuario.nombre}', '${usuario.correo}', '${usuario.direccion || ''}', '${usuario.telefono || ''}', '${usuario.rol}')">Editar</button>
                </td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error al cargar usuarios:', error);
    }
}

function abrirModalRegistro() {
    usuarioEnEdicion = null;
    document.getElementById('modalTitle').textContent = 'REGISTRAR NUEVO USUARIO';
    document.getElementById('submitButton').textContent = 'Guardar';
    document.getElementById('usuarioId').value = '';
    document.getElementById('nombre').value = '';
    document.getElementById('correo').value = '';
    document.getElementById('direccion').value = '';
    document.getElementById('telefono').value = '';
    document.getElementById('password').value = '';
    document.getElementById('rol').value = 'ADM';
    document.getElementById('registerModal').classList.remove('hidden');
    document.getElementById('registerModal').setAttribute('aria-hidden', 'false');
}

function cerrarModal() {
    document.getElementById('registerModal').classList.add('hidden');
    document.getElementById('registerModal').setAttribute('aria-hidden', 'true');
}

function editarUsuario(id, nombre, correo, direccion, telefono, rol) {
    usuarioEnEdicion = id;
    document.getElementById('modalTitle').textContent = 'EDITAR USUARIO';
    document.getElementById('submitButton').textContent = 'Actualizar';
    document.getElementById('usuarioId').value = id;
    document.getElementById('nombre').value = nombre;
    document.getElementById('correo').value = correo;
    document.getElementById('direccion').value = direccion;
    document.getElementById('telefono').value = telefono;
    document.getElementById('password').value = '';
    document.getElementById('rol').value = rol;
    document.getElementById('registerModal').classList.remove('hidden');
    document.getElementById('registerModal').setAttribute('aria-hidden', 'false');
}

async function eliminarUsuario(id) {
    if (!confirm('¿Seguro que desea eliminar este usuario?')) return;

    try {
        const response = await fetch(`${API_URL}/api/usuarios/${id}`, {
            method: 'DELETE'
        });
        const data = await response.json();
        if (!response.ok) {
            throw new Error(data.error || 'No se pudo eliminar el usuario');
        }
        alert(data.message);
        cargarUsuarios();
    } catch (error) {
        console.error('Error al eliminar usuario:', error);
        alert('No se pudo eliminar el usuario.');
    }
}

async function enviarFormularioUsuario(event) {
    event.preventDefault();

    const id = document.getElementById('usuarioId').value;
    const nombre = document.getElementById('nombre').value.trim();
    const correo = document.getElementById('correo').value.trim();
    const direccion = document.getElementById('direccion').value.trim();
    const telefono = document.getElementById('telefono').value.trim();
    const password = document.getElementById('password').value;
    const rol = document.getElementById('rol').value;

    if (!nombre || !correo || !rol || !direccion || !telefono || (!usuarioEnEdicion && !password)) {
        alert('Por favor complete los campos obligatorios.');
        return;
    }

    const usuario = { nombre, correo, direccion, telefono, rol };
    if (password) {
        usuario.password = password;
    }

    const url = usuarioEnEdicion ? `${API_URL}/api/usuarios/${usuarioEnEdicion}` : `${API_URL}/api/usuarios`;
    const method = usuarioEnEdicion ? 'PUT' : 'POST';

    try {
        const response = await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(usuario)
        });
        const data = await response.json();
        if (!response.ok) {
            throw new Error(data.error || 'Error en la operación');
        }
        alert(data.message || 'Operación realizada con éxito');
        cerrarModal();
        cargarUsuarios();
    } catch (error) {
        console.error('Error al guardar usuario:', error);
        alert(error.message || 'Error de conexión con el servidor.');
    }
}

window.addEventListener('DOMContentLoaded', () => {
    const rol = sessionStorage.getItem('id_rol');
    const listaUsuarios = document.getElementById('listaUsuarios');
    const registerForm = document.getElementById('registerForm');
    const openModalBtn = document.getElementById('openModalBtn');
    const closeModalBtn = document.getElementById('closeModalBtn');

    if (rol !== 'ADM') {
        redirectToLogin();
        return;
    }

    if (listaUsuarios) {
        cargarUsuarios();
    }

    if (registerForm) {
        registerForm.addEventListener('submit', enviarFormularioUsuario);
    }

    if (openModalBtn) {
        openModalBtn.addEventListener('click', abrirModalRegistro);
    }

    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', cerrarModal);
    }
});
