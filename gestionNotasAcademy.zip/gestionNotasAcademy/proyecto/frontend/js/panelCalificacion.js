const API_URL = 'http://localhost:3000/api';

document.addEventListener('DOMContentLoaded', async () => {
    const rol = sessionStorage.getItem('id_rol');
    if (rol !== 'PROF') {
        alert('Acceso no autorizado. Por favor inicie sesión como docente.');
        window.location.href = '../index.html';
        return;
    }

    await Promise.all([cargarEstudiantes(), cargarAsignaturas(), cargarCalificaciones()]);

    document.getElementById('nota1').addEventListener('input', calcularDefinitiva);
    document.getElementById('nota2').addEventListener('input', calcularDefinitiva);
    document.getElementById('nota3').addEventListener('input', calcularDefinitiva);

    const modalEl = document.getElementById('modalCalificacion');
    modalEl.addEventListener('show.bs.modal', () => {
        document.getElementById('formCalificacion').reset();
        document.getElementById('definitiva').value = '';
        limpiarErrores();
    });

    document.getElementById('btnGuardarCalificacion').addEventListener('click', guardarCalificacion);
});

function mostrarError(idCampo, mensaje) {
    const campo = document.getElementById(idCampo);
    campo.classList.add('is-invalid');
    let feedback = campo.nextElementSibling;
    if (!feedback || !feedback.classList.contains('invalid-feedback')) {
        feedback = document.createElement('div');
        feedback.className = 'invalid-feedback';
        campo.parentNode.insertBefore(feedback, campo.nextSibling);
    }
    feedback.textContent = mensaje;
}

function limpiarErrores() {
    document.querySelectorAll('#formCalificacion .is-invalid').forEach(el => {
        el.classList.remove('is-invalid');
    });
}

function notaValida(valor) {
    return !isNaN(valor) && valor >= 0 && valor <= 5;
}

async function cargarEstudiantes() {
    try {
        const response = await fetch(`${API_URL}/estudiantes`);
        if (!response.ok) throw new Error('No se pudo obtener la lista de estudiantes.');

        const estudiantes = await response.json();
        const selectEstudiante = document.getElementById('selectEstudiante');
        selectEstudiante.innerHTML = '<option value="">-- Seleccione un estudiante --</option>';

        estudiantes.forEach(estudiante => {
            selectEstudiante.innerHTML += `
                <option value="${estudiante.id}">${estudiante.nombre} (${estudiante.correo})</option>
            `;
        });
    } catch (error) {
        console.error(error);
        document.getElementById('selectEstudiante').innerHTML =
            '<option value="">Error al cargar estudiantes</option>';
    }
}

async function cargarAsignaturas() {
    try {
        const response = await fetch(`${API_URL}/asignaturas`);
        if (!response.ok) throw new Error('No se pudo obtener la lista de asignaturas.');

        const asignaturas = await response.json();
        const selectAsignatura = document.getElementById('selectAsignatura');
        selectAsignatura.innerHTML = '<option value="">-- Seleccione una asignatura --</option>';

        asignaturas.forEach(asignatura => {
            selectAsignatura.innerHTML += `
                <option value="${asignatura.id}">${asignatura.nombre_asignatura} - ${asignatura.grado} (Periodo ${asignatura.periodo})</option>
            `;
        });
    } catch (error) {
        console.error(error);
        document.getElementById('selectAsignatura').innerHTML =
            '<option value="">Error al cargar asignaturas</option>';
    }
}

async function cargarCalificaciones() {
    const cuerpoTabla = document.getElementById('cuerpoTabla');
    try {
        const response = await fetch(`${API_URL}/calificaciones`);
        if (!response.ok) throw new Error('No se pudo obtener las calificaciones.');

        const calificaciones = await response.json();
        if (!calificaciones.length) {
            cuerpoTabla.innerHTML =
                '<tr><td colspan="7" class="text-center">No hay calificaciones registradas.</td></tr>';
            return;
        }

        cuerpoTabla.innerHTML = calificaciones.map(registro => `
            <tr>
                <td>${registro.estudiante}</td>
                <td>${registro.asignatura}</td>
                <td>${Number(registro.nota1).toFixed(2)}</td>
                <td>${Number(registro.nota2).toFixed(2)}</td>
                <td>${Number(registro.nota3).toFixed(2)}</td>
                <td><strong>${Number(registro.definitiva).toFixed(2)}</strong></td>
                <td>${registro.fecha}</td>
            </tr>
        `).join('');
    } catch (error) {
        console.error(error);
        cuerpoTabla.innerHTML =
            '<tr><td colspan="7" class="text-center text-danger">No se pudieron cargar las calificaciones.</td></tr>';
    }
}

function calcularDefinitiva() {
    const n1 = parseFloat(document.getElementById('nota1').value);
    const n2 = parseFloat(document.getElementById('nota2').value);
    const n3 = parseFloat(document.getElementById('nota3').value);

    if (!isNaN(n1) && !isNaN(n2) && !isNaN(n3)) {
        document.getElementById('definitiva').value = ((n1 + n2 + n3) / 3).toFixed(2);
    } else {
        document.getElementById('definitiva').value = '';
    }
}

async function guardarCalificacion() {
    limpiarErrores();

    const estudiante = document.getElementById('selectEstudiante').value;
    const asignatura = document.getElementById('selectAsignatura').value;
    const nota1      = parseFloat(document.getElementById('nota1').value);
    const nota2      = parseFloat(document.getElementById('nota2').value);
    const nota3      = parseFloat(document.getElementById('nota3').value);
    const definitiva = parseFloat(document.getElementById('definitiva').value);

    let hayErrores = false;

    if (!estudiante) {
        mostrarError('selectEstudiante', 'Debe seleccionar un estudiante.');
        hayErrores = true;
    }
    if (!asignatura) {
        mostrarError('selectAsignatura', 'Debe seleccionar una asignatura.');
        hayErrores = true;
    }
    if (isNaN(nota1) || !notaValida(nota1)) {
        mostrarError('nota1', 'La nota debe estar entre 0.0 y 5.0.');
        hayErrores = true;
    }
    if (isNaN(nota2) || !notaValida(nota2)) {
        mostrarError('nota2', 'La nota debe estar entre 0.0 y 5.0.');
        hayErrores = true;
    }
    if (isNaN(nota3) || !notaValida(nota3)) {
        mostrarError('nota3', 'La nota debe estar entre 0.0 y 5.0.');
        hayErrores = true;
    }

    if (hayErrores) return;

    const btnGuardar = document.getElementById('btnGuardarCalificacion');
    btnGuardar.disabled = true;
    btnGuardar.textContent = 'Guardando...';

    try {
        const response = await fetch(`${API_URL}/calificaciones`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                id_estudiante: estudiante,
                id_asignatura: asignatura,
                nota1,
                nota2,
                nota3,
                definitiva
            })
        });

        const data = await response.json();
        if (!response.ok) throw new Error(data.error || 'Error al guardar la calificación.');

        const modalEl = document.getElementById('modalCalificacion');
        const modalInstance = bootstrap.Modal.getInstance(modalEl);
        if (modalInstance) modalInstance.hide();

        await cargarCalificaciones();

    } catch (error) {
        console.error(error);
        alert('No se pudo guardar la calificación: ' + error.message);
    } finally {
        btnGuardar.disabled = false;
        btnGuardar.textContent = 'Guardar';
    }
}