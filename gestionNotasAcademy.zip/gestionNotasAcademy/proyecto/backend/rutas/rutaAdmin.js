//esta ruta toma los datos del control administrador 
//y los envia al registro 

const express = require("express");
const router = express.Router();
const adminController = require("../controlesRoles/controlAdmin");
const crudController = require("../controlesRoles/crudAdmin");

// Esta ruta será accesible en: http://localhost:3000/api/usuarios
router.get("/usuarios", adminController.getUsuarios);
router.post("/usuarios", adminController.registrarUsuario);
router.put("/usuarios/:id", crudController.actualizarUsuario);
router.delete("/usuarios/:id", crudController.eliminarUsuario);

module.exports = router;