// Ruta para las operaciones del panel docente.
// Aquí se exponen las APIs para cargar asignaturas.

const express = require('express');
const router = express.Router();
const docenteController = require('../controlesRoles/controlDocente');

router.get('/asignaturas', docenteController.getAsignaturas);
router.get('/estudiantes', calificacionesController.getEstudiantes);
router.get('/calificaciones', calificacionesController.getCalificaciones);
router.post('/calificaciones', calificacionesController.guardarCalificacion);

module.exports = router;
