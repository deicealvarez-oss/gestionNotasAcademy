-- Crea la base de datos `registro_nuevo` con las tablas para roles, grado, asignaturas y calificaciones.
CREATE DATABASE IF NOT EXISTS registro_nuevo CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE registro_nuevo;

CREATE TABLE IF NOT EXISTS roles (
  id_rol VARCHAR(30) PRIMARY KEY,
  nombre_rol VARCHAR(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS grado (
  id_grado VARCHAR(12) PRIMARY KEY,
  Grado VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS usuarios (
  id_usuario INT AUTO_INCREMENT PRIMARY KEY,
  nombre_usuario VARCHAR(100) NOT NULL,
  correo_usuario VARCHAR(100) NOT NULL UNIQUE,
  direccion VARCHAR(100) NOT NULL,
  telefono VARCHAR(20) NOT NULL,
  contraseña_usuario VARCHAR(255) NOT NULL,
  id_rol_usuario VARCHAR(30) NOT NULL,
  CONSTRAINT fk_usuario_rol FOREIGN KEY (id_rol_usuario) REFERENCES roles(id_rol)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS asignaturas (
  id_asignatura INT AUTO_INCREMENT PRIMARY KEY,
  nombre_asignatura VARCHAR(100) NOT NULL,
  periodo VARCHAR(50) NOT NULL,
  grado VARCHAR(100) NOT NULL,
  UNIQUE KEY uq_asignatura (nombre_asignatura, periodo, grado)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS calificaciones (
  id_calificacion INT AUTO_INCREMENT PRIMARY KEY,
  id_estudiante INT NOT NULL,
  id_asignatura INT NOT NULL,
  nota1 FLOAT NOT NULL,
  nota2 FLOAT NOT NULL,
  nota3 FLOAT NOT NULL,
  definitiva FLOAT NOT NULL,
  fecha DATE NOT NULL,
  CONSTRAINT fk_calificaciones_usuario FOREIGN KEY (id_estudiante) REFERENCES usuarios(id_usuario),
  CONSTRAINT fk_calificaciones_asignatura FOREIGN KEY (id_asignatura) REFERENCES asignaturas(id_asignatura)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE OR REPLACE VIEW vw_usuarios_con_rol AS
SELECT u.id_usuario AS id, u.nombre_usuario AS nombre, u.correo_usuario AS correo, u.direccion, u.telefono, r.nombre_rol AS rol
FROM usuarios u
JOIN roles r ON u.id_rol_usuario = r.id_rol;

INSERT IGNORE INTO roles (id_rol, nombre_rol) VALUES ('ADM', 'Administrador'), ('EST', 'Estudiante'), ('PROF', 'Profesor');
INSERT IGNORE INTO grado (id_grado, Grado) VALUES ('G1', 'Primero'), ('G2', 'Segundo'), ('G3', 'Tercero');
INSERT IGNORE INTO asignaturas (nombre_asignatura, periodo, grado) VALUES
  ('Matemáticas', '1', 'Primero'),
  ('Ciencias', '1', 'Primero'),
  ('Lengua', '1', 'Primero');