const { pool } = require('../registro.js');

// Helper manejo de errores y respuestas en una sola línea
const handleRes = (res, status, success, msg) => res.status(status).json({ success, [success ? 'message' : 'error']: msg });

exports.actualizarUsuario = async (req, res) => {
  const { id } = req.params;
  const { nombre, correo, direccion, telefono, password, rol } = req.body;

  if (!nombre || !correo || !rol) return handleRes(res, 400, false, 'Faltan datos obligatorios.');

  try {
    let query;
    let params;

    if (password) {
      query = `UPDATE usuarios SET nombre_usuario=?, correo_usuario=?, direccion=?, telefono=?, contraseña_usuario=?, id_rol_usuario=? WHERE id_usuario=?`;
      params = [nombre, correo, direccion, telefono, password, rol, id];
    } else {
      query = `UPDATE usuarios SET nombre_usuario=?, correo_usuario=?, direccion=?, telefono=?, id_rol_usuario=? WHERE id_usuario=?`;
      params = [nombre, correo, direccion, telefono, rol, id];
    }

    const [result] = await pool.execute(query, params);

    return result.affectedRows > 0 
      ? handleRes(res, 200, true, 'Usuario actualizado.') 
      : handleRes(res, 404, false, 'Usuario no encontrado.');
  } catch (e) {
    return handleRes(res, 500, false, e.message);
  }
};

exports.eliminarUsuario = async (req, res) => {
  try {
    const [result] = await pool.execute('DELETE FROM usuarios WHERE id_usuario = ?', [req.params.id]);
    
    return result.affectedRows > 0 
      ? handleRes(res, 200, true, 'Usuario eliminado.') 
      : handleRes(res, 404, false, 'Usuario no encontrado.');
  } catch (e) {
    return handleRes(res, 500, false, e.message);
  }
};