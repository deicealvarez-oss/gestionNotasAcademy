const { pool } = require('../registro.js');

//trae las asignaturas que da el docente
exports.getAsignaturas = async (req, res) => {
  try {
    const query = `
      SELECT id_asignatura AS id,
             nombre_asignatura,
             periodo,
             grado
      FROM asignaturas
      ORDER BY nombre_asignatura ASC;
    `;

    const [rows] = await pool.execute(query);
    res.json(rows);
  } catch (error) {
    console.error('No se pueden traer los datos de las asignaturas:', error.message);
    res.status(500).json({ error: 'Error interno del servidor al listar asignaturas.' });
  }
};
