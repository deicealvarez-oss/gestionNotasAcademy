const { pool } = require('../registro.js');

//lista de estudiantes
exports.getEstudiantes = async (req, res) => {
  try {
    const query = `
      SELECT id_usuario AS id,
             nombre_usuario AS nombre,
             correo_usuario AS correo
      FROM usuarios
      WHERE id_rol_usuario = 'EST'
      ORDER BY nombre_usuario ASC;
    `;

    const [rows] = await pool.execute(query);
    res.json(rows);
  } catch (error) {
    console.error('Error al obtener estudiantes:', error.message);
    res.status(500).json({ error: 'Error interno al obtener estudiantes.' });
  }
};

//optiene las calificaciones
exports.getCalificaciones = async (req, res) => {
  try {
    const query = `
      SELECT c.id_calificacion AS id,
             u.nombre_usuario AS estudiante,
             a.nombre_asignatura AS asignatura,
             c.nota1,
             c.nota2,
             c.nota3,
             c.definitiva,
             DATE_FORMAT(c.fecha, '%Y-%m-%d') AS fecha
      FROM calificaciones c
      JOIN usuarios u ON c.id_estudiante = u.id_usuario
      JOIN asignaturas a ON c.id_asignatura = a.id_asignatura
      ORDER BY c.fecha DESC, c.id_calificacion DESC;
    `;

    const [rows] = await pool.execute(query);
    res.json(rows);
  } catch (error) {
    console.error('Error al obtener calificaciones:', error.message);
    res.status(500).json({ error: 'Error interno al obtener calificaciones.' });
  }
};

//guarda las calificaciones
exports.guardarCalificacion = async (req, res) => {
  const { id_estudiante, id_asignatura, nota1, nota2, nota3, definitiva } = req.body;

  if (!id_estudiante || !id_asignatura || nota1 == null || nota2 == null || nota3 == null || definitiva == null) {
    return res.status(400).json({ error: 'Faltan datos obligatorios para guardar la calificación.' });
  }

  try {
    const query = `
      INSERT INTO calificaciones (
        id_estudiante,
        id_asignatura,
        nota1,
        nota2,
        nota3,
        definitiva,
        fecha
      ) VALUES (?, ?, ?, ?, ?, ?, CURRENT_DATE())
    `;

    const [result] = await pool.execute(query, [
      id_estudiante,
      id_asignatura,
      parseFloat(nota1),
      parseFloat(nota2),
      parseFloat(nota3),
      parseFloat(definitiva)
    ]);

    res.status(201).json({ message: 'Calificación guardada con éxito.', id: result.insertId });
  } catch (error) {
    console.error('Error al guardar calificación:', error.message);
    res.status(500).json({ error: 'Error interno del servidor al guardar la calificación.' });
  }
};